from uuid import UUID
from typing import Dict, List, Any, Optional
from database.manager import SupabaseManager
from database.base_repository import BaseRepository
import logging

logger = logging.getLogger("repository.profile")

class ProfileRepository(BaseRepository):
    """
    Repositório para operações relacionadas a perfis de cliente.
    """
    
    def __init__(self, db_manager: SupabaseManager):
        """
        Inicializa o repositório de perfis.
        
        Args:
            db_manager: Gerenciador de conexão com o banco de dados
        """
        super().__init__(db_manager, "client_profiles")
    
    async def create_profile(self, user_id: Optional[UUID] = None) -> UUID:
        """
        Cria um novo perfil de cliente.
        
        Args:
            user_id: ID do usuário (opcional)
            
        Returns:
            ID do perfil criado
        """
        try:
            data = {
                "completion_score_personal": 0.0,
                "completion_score_family": 0.0,
                "completion_score_assets": 0.0,
                "completion_score_goals": 0.0,
                "completion_score_overall": 0.0
            }
            
            if user_id:
                data["user_id"] = str(user_id)
            
            result = await self.create(data)
            
            return UUID(result["profile_id"])
        except Exception as e:
            logger.error(f"Erro ao criar perfil: {str(e)}")
            raise
    
    async def get_profile(self, profile_id: UUID) -> Optional[Dict[str, Any]]:
        """
        Obtém um perfil pelo ID.
        
        Args:
            profile_id: ID do perfil
            
        Returns:
            Dados do perfil ou None se não encontrado
        """
        return await self.find_by_id("profile_id", str(profile_id))
    
    async def update_completion_scores(self, profile_id: UUID, scores: Dict[str, float]) -> None:
        """
        Atualiza as pontuações de completude de um perfil.
        
        Args:
            profile_id: ID do perfil
            scores: Dicionário com as pontuações a serem atualizadas
        """
        try:
            data = {}
            
            if "personal" in scores:
                data["completion_score_personal"] = scores["personal"]
            
            if "family" in scores:
                data["completion_score_family"] = scores["family"]
            
            if "assets" in scores:
                data["completion_score_assets"] = scores["assets"]
            
            if "goals" in scores:
                data["completion_score_goals"] = scores["goals"]
            
            if "overall" in scores:
                data["completion_score_overall"] = scores["overall"]
            
            await self.update(
                id_field="profile_id",
                id_value=str(profile_id),
                data=data
            )
        except Exception as e:
            logger.error(f"Erro ao atualizar pontuações de completude do perfil {profile_id}: {str(e)}")
            raise
    
    async def update_notes(self, profile_id: UUID, notes: str) -> None:
        """
        Atualiza as notas de um perfil.
        
        Args:
            profile_id: ID do perfil
            notes: Notas a serem atualizadas
        """
        try:
            await self.update(
                id_field="profile_id",
                id_value=str(profile_id),
                data={"notes": notes}
            )
        except Exception as e:
            logger.error(f"Erro ao atualizar notas do perfil {profile_id}: {str(e)}")
            raise
